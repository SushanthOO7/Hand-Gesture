from pathlib import Path
from tkinter.constants import ANCHOR, N
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from tkinter import Frame, Canvas, Entry, PhotoImage, N
import controller as db_controller

OUTPUT_PATH = Path(__file__).parent
ASSETS_PATH = OUTPUT_PATH / Path("./assets")


def relative_to_assets(path: str) -> Path:
    return ASSETS_PATH / Path(path)


def dashboard():
    Dashboard()


class Dashboard(Frame):
    def __init__(self, parent, controller=None, *args, **kwargs):
        Frame.__init__(self, parent, *args, **kwargs)
        self.parent = parent

        self.configure(bg="#FFFFFF")

        canvas = Canvas(
            self,
            bg="#FFFFFF",
            height=432,
            width=797,
            bd=0,
            highlightthickness=0,
            relief="ridge",
        )

        canvas.place(x=0, y=0)

        # Vacant Text
        canvas.create_text(
            164.0,
            63.0,
            anchor="ne",
            text=db_controller.vacant(),
            fill="#5E95FF",
            font=("Montserrat Bold", 48 * -1),
            justify="right",
        )

        canvas.entry_image_2 = PhotoImage(file=relative_to_assets("entry_2.png"))
        entry_bg_2 = canvas.create_image(299.0, 81.0, image=canvas.entry_image_2)
        entry_2 = Entry(
            self,
            bd=0,
            bg="#EFEFEF",
            highlightthickness=0,
            font=("Montserrat Bold", 150),
        )
        entry_2.place(x=239.0, y=30.0 + 2, width=120.0, height=0)

        canvas.create_text(
            240.0,
            45.0,
            anchor="nw",
            text="Booked",
            fill="#5E95FF",
            font=("Montserrat Bold", 14 * -1),
        )

        canvas.create_text(
            346.0,
            63.0,
            anchor="ne",
            text=db_controller.booked(),
            fill="#5E95FF",
            font=("Montserrat Bold", 48 * -1),
            justify="right",
        )

        canvas.entry_image_7 = PhotoImage(file=relative_to_assets("entry_7.png"))
        entry_bg_7 = canvas.create_image(483.0, 81.0, image=canvas.entry_image_7)
        entry_7 = Entry(
            self,
            bd=0,
            bg="#EFEFEF",
            highlightthickness=0,
            font=("Montserrat Bold", 150),
        )
        entry_7.place(x=423.0, y=30.0 + 2, width=120.0, height=0)

        canvas.create_text(
            424.0,
            45.0,
            anchor="nw",
            text="Hotel Value",
            fill="#5E95FF",
            font=("Montserrat Bold", 14 * -1),
        )

        canvas.create_text(
            540.0,
            63.0,
            anchor="ne",
            text=db_controller.get_total_hotel_value(),
            fill="#5E95FF",
            font=("Montserrat Bold", 48 * -1),
        )

        canvas.entry_image_8 = PhotoImage(file=relative_to_assets("entry_8.png"))
        entry_bg_8 = canvas.create_image(667.0, 81.0, image=canvas.entry_image_8)
        entry_8 = Entry(
            self,
            bd=0,
            bg="#EFEFEF",
            highlightthickness=0,
            font=("Montserrat Bold", 150),
        )
        entry_8.place(x=607.0, y=30.0 + 2, width=120.0, height=0)



        canvas.create_text(
            712.0,
            63.0,
            anchor="ne",
            text=db_controller.meals(),
            fill="#5E95FF",
            font=("Montserrat Bold", 48 * -1),
        )
        canvas.image_image_1 = PhotoImage(file=relative_to_assets("1.png"))
        image_1 = canvas.create_image(400.0, 80.0, image=canvas.image_image_1)

        canvas.image_image_2 = PhotoImage(file=relative_to_assets("image_1.png"))
        image_2 = canvas.create_image(300.0, 330.0, image=canvas.image_image_2)

        canvas.image_image_3 = PhotoImage(file=relative_to_assets("5.png"))
        image_3 = canvas.create_image(120.0, 80.0, image=canvas.image_image_3)

        canvas.image_image_4 = PhotoImage(file=relative_to_assets("6.png"))
        image_4 = canvas.create_image(680.0, 80.0, image=canvas.image_image_4)

        canvas.image_image_5 = PhotoImage(file=relative_to_assets("7.png"))
        image_5 = canvas.create_image(480.0,240.0, image=canvas.image_image_5)

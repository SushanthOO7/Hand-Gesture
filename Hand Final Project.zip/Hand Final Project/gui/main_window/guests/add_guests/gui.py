from pathlib import Path
from gui.main_window.guests.add_guests.HandTrackingModuleWrite import *
import cv2
import os
import numpy as np
from gui.main_window.guests.add_guests.Writing import *


from tkinter import (
    Frame,
    Canvas,
    Entry,
    StringVar,
    Text,
    Button,
    PhotoImage,
    messagebox,
)
import controller as db_controller

OUTPUT_PATH = Path(__file__).parent
ASSETS_PATH = OUTPUT_PATH / Path("./assets")


def relative_to_assets(path: str) -> Path:
    return ASSETS_PATH / Path(path)


def add_guests():
    AddGuests()


class AddGuests(Frame):
    def __init__(self, parent, controller=None, *args, **kwargs):
        Frame.__init__(self, parent, *args, **kwargs)
        self.parent = parent
        self.data = {
            "name": StringVar(),
            "address": StringVar(),
            "phone": StringVar(),
            "email": StringVar(),
        }

        self.configure(bg="#FFFFFF")

        self.canvas = Canvas(
            self,
            bg="#FFFFFF",
            height=432,
            width=797,
            bd=0,
            highlightthickness=0,
            relief="ridge",
        )

        self.button_image_1 = PhotoImage(file=relative_to_assets("1.png"))
        button_1 = Button(
            self,
            image=self.button_image_1,
            borderwidth=0,
            highlightthickness=0,
            command=self.save,
            relief="flat",
        )
        button_1.place(x=164.0, y=322.0, width=190.0, height=48.0)






    # Save the data to the database
    def save(self):
        write()
